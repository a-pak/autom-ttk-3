# Automaation-tietotekniikka-3

main.py ajetaan ohjelmaa
